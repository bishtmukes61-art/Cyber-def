/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Uncomment for static export (GitHub Pages)
  // output: 'export',
  // basePath: '/your-repo-name', // Replace with your GitHub repo name
}

export default nextConfig
