import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// This is your local "database" - edit credentials here
// Users can sign up and their data will be stored in localStorage
export const DEFAULT_USERS = [
  {
    id: '1',
    email: 'admin@hacker.com',
    password: 'admin123',
    name: 'Admin Hacker',
    avatar: '/images/hero-bg.jpg'
  },
  {
    id: '2',
    email: 'demo@hacker.com',
    password: 'demo123',
    name: 'Demo User',
    avatar: '/images/hero-bg.jpg'
  }
]

export interface User {
  id: string
  email: string
  password: string
  name: string
  avatar: string
}

interface AuthState {
  users: User[]
  currentUser: User | null
  isAuthenticated: boolean
  signUp: (email: string, password: string, name: string) => { success: boolean; message: string }
  signIn: (email: string, password: string) => { success: boolean; message: string }
  signOut: () => void
  socialSignIn: (provider: string) => { success: boolean; message: string }
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      users: DEFAULT_USERS,
      currentUser: null,
      isAuthenticated: false,

      signUp: (email: string, password: string, name: string) => {
        const { users } = get()
        
        // Check if email already exists
        if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
          return { success: false, message: 'Email already exists!' }
        }

        // Validate
        if (!email || !password || !name) {
          return { success: false, message: 'All fields are required!' }
        }

        if (password.length < 6) {
          return { success: false, message: 'Password must be at least 6 characters!' }
        }

        // Create new user
        const newUser: User = {
          id: Date.now().toString(),
          email: email.toLowerCase(),
          password,
          name,
          avatar: '/images/hero-bg.jpg'
        }

        set({ 
          users: [...users, newUser],
          currentUser: newUser,
          isAuthenticated: true
        })

        return { success: true, message: 'Account created successfully!' }
      },

      signIn: (email: string, password: string) => {
        const { users } = get()
        
        const user = users.find(
          u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
        )

        if (!user) {
          return { success: false, message: 'Invalid email or password!' }
        }

        set({ currentUser: user, isAuthenticated: true })
        return { success: true, message: 'Welcome back, Hacker!' }
      },

      signOut: () => {
        set({ currentUser: null, isAuthenticated: false })
      },

      socialSignIn: (provider: string) => {
        // Simulate social sign in
        const socialUser: User = {
          id: Date.now().toString(),
          email: `user@${provider.toLowerCase()}.com`,
          password: '',
          name: `${provider} User`,
          avatar: '/images/hero-bg.jpg'
        }

        set({ currentUser: socialUser, isAuthenticated: true })
        return { success: true, message: `Signed in with ${provider}!` }
      }
    }),
    {
      name: 'hacker-auth-storage',
    }
  )
)
