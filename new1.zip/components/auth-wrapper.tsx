'use client'

import { useEffect, useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { useAuthStore } from '@/lib/auth-store'

const publicPaths = ['/', '/signin']

export function AuthWrapper({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const pathname = usePathname()
  const { isAuthenticated } = useAuthStore()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const isPublicPath = publicPaths.includes(pathname)
    
    if (!isAuthenticated && !isPublicPath) {
      router.push('/')
    } else if (isAuthenticated && isPublicPath) {
      router.push('/home')
    }
    
    setIsLoading(false)
  }, [isAuthenticated, pathname, router])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return <>{children}</>
}
