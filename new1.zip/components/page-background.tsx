'use client'

import Image from 'next/image'

interface PageBackgroundProps {
  image: string
  overlay?: 'dark' | 'gradient' | 'none'
  children: React.ReactNode
}

export function PageBackground({ image, overlay = 'dark', children }: PageBackgroundProps) {
  return (
    <div className="min-h-screen relative">
      {/* Background Image */}
      <div className="fixed inset-0 z-0">
        <Image
          src={image}
          alt="Background"
          fill
          className="object-cover"
          priority
          quality={80}
        />
        
        {/* Overlay */}
        {overlay === 'dark' && (
          <div className="absolute inset-0 bg-black/70" />
        )}
        {overlay === 'gradient' && (
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/90" />
        )}
        
        {/* Scanlines */}
        <div className="absolute inset-0 scanlines opacity-30" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  )
}
