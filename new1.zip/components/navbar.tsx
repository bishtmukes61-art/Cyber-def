'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { useState } from 'react'
import { useAuthStore } from '@/lib/auth-store'
import { 
  Menu, 
  X, 
  Terminal, 
  Home, 
  User, 
  Wrench, 
  FileText, 
  FolderGit2, 
  Mail,
  LogOut
} from 'lucide-react'

const navLinks = [
  { href: '/home', label: 'Home', icon: Home },
  { href: '/about', label: 'About', icon: User },
  { href: '/tools', label: 'Tools', icon: Wrench },
  { href: '/blog', label: 'Blog', icon: FileText },
  { href: '/projects', label: 'Projects', icon: FolderGit2 },
  { href: '/contact', label: 'Contact', icon: Mail },
]

export function Navbar() {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)
  const { currentUser, signOut, isAuthenticated } = useAuthStore()

  if (!isAuthenticated) return null

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-cyan-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/home" className="flex items-center gap-2 group">
            <Terminal className="w-6 h-6 text-cyan-400 group-hover:text-red-400 transition-colors" />
            <span className="text-xl font-bold text-cyan-400 glitch-text group-hover:text-red-400 transition-colors">
              Cyber Defence
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => {
              const isActive = pathname === link.href
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center gap-2 px-3 py-2 text-sm transition-all duration-300 ${
                    isActive 
                      ? 'text-cyan-400 neon-cyan' 
                      : 'text-gray-400 hover:text-cyan-400'
                  }`}
                >
                  <link.icon className="w-4 h-4" />
                  {link.label}
                </Link>
              )
            })}
          </div>

          {/* User Menu */}
          <div className="hidden md:flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center">
                {currentUser?.name?.charAt(0) || 'H'}
              </div>
              <span>{currentUser?.name || 'Hacker'}</span>
            </div>
            <button
              onClick={() => {
                signOut()
                window.location.href = '/'
              }}
              className="flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:text-red-300 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 text-cyan-400"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass border-t border-cyan-500/20"
          >
            <div className="px-4 py-4 space-y-2">
              {navLinks.map((link) => {
                const isActive = pathname === link.href
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                      isActive 
                        ? 'bg-cyan-500/10 text-cyan-400' 
                        : 'text-gray-400 hover:bg-gray-800/50'
                    }`}
                  >
                    <link.icon className="w-5 h-5" />
                    {link.label}
                  </Link>
                )
              })}
              <button
                onClick={() => {
                  signOut()
                  setIsOpen(false)
                  window.location.href = '/'
                }}
                className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
              >
                <LogOut className="w-5 h-5" />
                Logout
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}
