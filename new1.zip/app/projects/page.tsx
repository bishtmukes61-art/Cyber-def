'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { useAuthStore } from '@/lib/auth-store'
import { Navbar } from '@/components/navbar'
import { 
  Github, 
  ExternalLink, 
  Star, 
  GitFork,
  Shield,
  Bug,
  Terminal,
  Lock,
  Wifi,
  Database
} from 'lucide-react'

const projects = [
  {
    title: 'VulnScanner Pro',
    description: 'Automated vulnerability scanner with AI-powered analysis for web applications. Detects OWASP Top 10 vulnerabilities.',
    image: '/images/hero-bg.jpg',
    tags: ['Python', 'AI', 'Security'],
    icon: Shield,
    github: 'https://github.com',
    demo: '#',
    stars: 234,
    forks: 45,
    color: 'from-cyan-500 to-blue-600'
  },
  {
    title: 'NetRecon Toolkit',
    description: 'Comprehensive network reconnaissance toolkit for penetration testers. Includes port scanning, service detection, and reporting.',
    image: '/images/tools-bg.jpg',
    tags: ['Python', 'Bash', 'Networking'],
    icon: Wifi,
    github: 'https://github.com',
    demo: '#',
    stars: 189,
    forks: 32,
    color: 'from-purple-500 to-pink-600'
  },
  {
    title: 'SQLi Exploiter',
    description: 'Advanced SQL injection exploitation framework with automated payload generation and database extraction.',
    image: '/images/auth-bg.jpg',
    tags: ['Python', 'SQL', 'Exploitation'],
    icon: Database,
    github: 'https://github.com',
    demo: '#',
    stars: 312,
    forks: 67,
    color: 'from-red-500 to-orange-600'
  },
  {
    title: 'CryptoBreaker',
    description: 'Cryptographic analysis and hash cracking tool with support for various encryption algorithms and rainbow tables.',
    image: '/images/about-bg.jpg',
    tags: ['Rust', 'Crypto', 'GPU'],
    icon: Lock,
    github: 'https://github.com',
    demo: '#',
    stars: 156,
    forks: 23,
    color: 'from-yellow-500 to-amber-600'
  },
  {
    title: 'BugHunter Framework',
    description: 'Bug bounty hunting framework with automated recon, subdomain enumeration, and vulnerability detection.',
    image: '/images/blog-bg.jpg',
    tags: ['Go', 'Automation', 'Bug Bounty'],
    icon: Bug,
    github: 'https://github.com',
    demo: '#',
    stars: 421,
    forks: 89,
    color: 'from-green-500 to-teal-600'
  },
  {
    title: 'ShellGen',
    description: 'Reverse shell generator with obfuscation and encoding options. Supports multiple languages and platforms.',
    image: '/images/projects-bg.jpg',
    tags: ['Python', 'Shells', 'Obfuscation'],
    icon: Terminal,
    github: 'https://github.com',
    demo: '#',
    stars: 278,
    forks: 54,
    color: 'from-indigo-500 to-purple-600'
  }
]

export default function ProjectsPage() {
  const router = useRouter()
  const { isAuthenticated } = useAuthStore()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/')
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen relative">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <Image
          src="/images/projects-bg.jpg"
          alt="Projects Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/80" />
        <div className="absolute inset-0 scanlines opacity-20" />
      </div>

      <Navbar />

      {/* Content */}
      <main className="relative z-10 pt-20 pb-16">
        {/* Header */}
        <section className="px-4 py-12">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                <span className="text-green-400 glitch-text">Security</span>{' '}
                <span className="text-white">Projects</span>
              </h1>
              <p className="text-gray-400 max-w-2xl mx-auto">
                Open-source tools and frameworks for cybersecurity professionals
              </p>
            </motion.div>

            {/* Projects Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project, index) => (
                <motion.div
                  key={project.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                  className="glass rounded-xl overflow-hidden border border-gray-800 hover:border-green-500/50 transition-all group"
                >
                  {/* Project Image */}
                  <div className="relative h-40">
                    <Image
                      src={project.image}
                      alt={project.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
                    
                    {/* Icon */}
                    <div className={`absolute bottom-4 left-4 w-12 h-12 rounded-xl bg-gradient-to-br ${project.color} flex items-center justify-center`}>
                      <project.icon className="w-6 h-6 text-white" />
                    </div>

                    {/* Actions */}
                    <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <a
                        href={project.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-lg bg-black/50 text-white hover:bg-black/70 transition-colors"
                      >
                        <Github className="w-4 h-4" />
                      </a>
                      <a
                        href={project.demo}
                        className="p-2 rounded-lg bg-black/50 text-white hover:bg-black/70 transition-colors"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-green-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-gray-500 text-sm mb-4 line-clamp-2">
                      {project.description}
                    </p>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-1 text-xs rounded bg-gray-800 text-gray-400"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Stats */}
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500" />
                        {project.stars}
                      </span>
                      <span className="flex items-center gap-1">
                        <GitFork className="w-4 h-4" />
                        {project.forks}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-16 text-center"
            >
              <div className="glass rounded-xl p-8 border border-gray-800 max-w-2xl mx-auto">
                <Github className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-2xl font-bold text-white mb-2">
                  Want to see more?
                </h3>
                <p className="text-gray-500 mb-6">
                  Check out my GitHub profile for more open-source security tools and contributions.
                </p>
                <a
                  href="https://github.com/YOUR_USERNAME"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-lg hover:from-green-400 hover:to-teal-500 transition-all"
                >
                  <Github className="w-5 h-5" />
                  View GitHub Profile
                </a>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
    </div>
  )
}
