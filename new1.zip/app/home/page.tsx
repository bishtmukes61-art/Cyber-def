'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { useAuthStore } from '@/lib/auth-store'
import { Navbar } from '@/components/navbar'
import { TypingEffect } from '@/components/typing-effect'
import { 
  Shield, 
  Wifi, 
  Bug, 
  Database, 
  Key, 
  Search, 
  Terminal,
  Skull,
  Zap,
  Lock,
  Globe,
  FileSearch
} from 'lucide-react'

const kaliTools = [
  {
    name: 'Nmap',
    icon: Search,
    description: 'Network exploration and security auditing tool',
    command: 'nmap -sV -sC target.com',
    color: 'from-cyan-500 to-blue-600'
  },
  {
    name: 'Metasploit',
    icon: Skull,
    description: 'Penetration testing framework for exploits',
    command: 'msfconsole',
    color: 'from-red-500 to-orange-600'
  },
  {
    name: 'Wireshark',
    icon: Wifi,
    description: 'Network protocol analyzer for traffic capture',
    command: 'wireshark',
    color: 'from-blue-500 to-purple-600'
  },
  {
    name: 'Aircrack-ng',
    icon: Wifi,
    description: 'WiFi security auditing tool suite',
    command: 'aircrack-ng capture.cap -w wordlist.txt',
    color: 'from-green-500 to-teal-600'
  },
  {
    name: 'Burp Suite',
    icon: Bug,
    description: 'Web application security testing platform',
    command: 'burpsuite',
    color: 'from-orange-500 to-red-600'
  },
  {
    name: 'SQLMap',
    icon: Database,
    description: 'Automatic SQL injection exploitation tool',
    command: 'sqlmap -u "url" --dbs',
    color: 'from-purple-500 to-pink-600'
  },
  {
    name: 'Hashcat',
    icon: Key,
    description: 'Advanced password recovery tool',
    command: 'hashcat -m 0 hash.txt wordlist.txt',
    color: 'from-yellow-500 to-orange-600'
  },
  {
    name: 'John the Ripper',
    icon: Lock,
    description: 'Password cracking tool',
    command: 'john --wordlist=rockyou.txt hashes.txt',
    color: 'from-pink-500 to-red-600'
  },
  {
    name: 'Nikto',
    icon: Globe,
    description: 'Web server vulnerability scanner',
    command: 'nikto -h target.com',
    color: 'from-indigo-500 to-purple-600'
  },
  {
    name: 'Dirbuster',
    icon: FileSearch,
    description: 'Directory and file brute-forcing tool',
    command: 'dirb http://target.com wordlist.txt',
    color: 'from-teal-500 to-cyan-600'
  },
  {
    name: 'Hydra',
    icon: Zap,
    description: 'Fast network login cracker',
    command: 'hydra -l admin -P pass.txt ssh://target',
    color: 'from-red-600 to-pink-600'
  },
  {
    name: 'BeEF',
    icon: Terminal,
    description: 'Browser exploitation framework',
    command: 'beef-xss',
    color: 'from-amber-500 to-yellow-600'
  }
]

export default function HomePage() {
  const router = useRouter()
  const { currentUser, isAuthenticated } = useAuthStore()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/')
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen relative">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <Image
          src="/images/hero-bg.jpg"
          alt="Cyber Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/90" />
        <div className="absolute inset-0 scanlines opacity-20" />
      </div>

      <Navbar />

      {/* Content */}
      <main className="relative z-10 pt-20">
        {/* Hero Section */}
        <section className="px-4 py-20">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <div className="flex justify-center mb-6">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-red-500 via-purple-500 to-cyan-500 p-1">
                  <div className="w-full h-full rounded-full bg-black flex items-center justify-center overflow-hidden">
                    <Image
                      src="/images/hero-bg.jpg"
                      alt="Avatar"
                      width={96}
                      height={96}
                      className="object-cover rounded-full"
                    />
                  </div>
                </div>
              </div>
              
              <h1 className="text-4xl md:text-6xl font-bold mb-4">
                <span className="text-gray-100">Welcome, </span>
                <span className="text-cyan-400 glitch-text">{currentUser?.name || 'Cyber'}</span>
              </h1>
              
              <div className="text-lg md:text-xl text-gray-400 h-8 mb-8">
                <TypingEffect 
                  text="[ System Access Granted ] // Initializing cybersecurity toolkit..." 
                  speed={40}
                />
              </div>

              <div className="flex flex-wrap justify-center gap-4">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="px-6 py-3 glass rounded-lg border border-cyan-500/30 flex items-center gap-2"
                >
                  <Shield className="w-5 h-5 text-cyan-400" />
                  <span className="text-cyan-400">Ethical Hacker</span>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="px-6 py-3 glass rounded-lg border border-red-500/30 flex items-center gap-2"
                >
                  <Bug className="w-5 h-5 text-red-400" />
                  <span className="text-red-400">Pentester</span>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="px-6 py-3 glass rounded-lg border border-purple-500/30 flex items-center gap-2"
                >
                  <Terminal className="w-5 h-5 text-purple-400" />
                  <span className="text-purple-400">Security Researcher</span>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Kali Linux Tools Section */}
        <section className="px-4 py-16">
          <div className="max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                <span className="text-red-400 glitch-text">Kali Linux</span>{' '}
                <span className="text-gray-100">Arsenal</span>
              </h2>
              <p className="text-gray-500 max-w-2xl mx-auto">
                Essential penetration testing tools for security professionals
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {kaliTools.map((tool, index) => (
                <motion.div
                  key={tool.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="cyber-card glass rounded-xl p-6 border border-gray-800 hover:border-cyan-500/50 transition-all cursor-pointer group"
                >
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${tool.color} flex items-center justify-center mb-4 group-hover:shadow-lg transition-shadow`}>
                    <tool.icon className="w-6 h-6 text-white" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                    {tool.name}
                  </h3>
                  
                  <p className="text-gray-500 text-sm mb-4">
                    {tool.description}
                  </p>
                  
                  <div className="bg-black/50 rounded-lg p-3 border border-gray-800">
                    <code className="text-xs text-cyan-400 font-mono">
                      $ {tool.command}
                    </code>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="px-4 py-16">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[
                { label: 'Vulnerabilities Found', value: '500+', color: 'text-red-400' },
                { label: 'Systems Secured', value: '150+', color: 'text-cyan-400' },
                { label: 'Bug Bounties', value: '$50K+', color: 'text-green-400' },
                { label: 'CTF Wins', value: '25+', color: 'text-purple-400' },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="glass rounded-xl p-6 text-center border border-gray-800"
                >
                  <div className={`text-3xl md:text-4xl font-bold ${stat.color} mb-2`}>
                    {stat.value}
                  </div>
                  <div className="text-gray-500 text-sm">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="px-4 py-8 border-t border-gray-800">
          <div className="max-w-6xl mx-auto text-center">
            <p className="text-gray-600 text-sm">
              © 2026 Cyber Defence. All rights reserved.
            </p>
            <p className="text-gray-700 text-xs mt-2">
               • Follow For more cyber security contents 
            </p>
          </div>
        </footer>
      </main>
    </div>
  )
}
