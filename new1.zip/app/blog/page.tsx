'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { useAuthStore } from '@/lib/auth-store'
import { Navbar } from '@/components/navbar'
import { 
  Calendar, 
  Clock, 
  Tag, 
  ArrowRight,
  Eye
} from 'lucide-react'

const blogPosts = [
  {
    id: 1,
    title: 'Introduction to Buffer Overflow Attacks',
    excerpt: 'Learn the fundamentals of buffer overflow vulnerabilities and how to exploit them ethically in CTF challenges.',
    image: '/images/hero-bg.jpg',
    date: '2024-03-15',
    readTime: '10 min',
    tags: ['Exploitation', 'Binary'],
    views: 1524
  },
  {
    id: 2,
    title: 'Web Application Security Testing 101',
    excerpt: 'A comprehensive guide to testing web applications for common vulnerabilities like XSS, SQLi, and CSRF.',
    image: '/images/auth-bg.jpg',
    date: '2024-03-10',
    readTime: '15 min',
    tags: ['Web Security', 'OWASP'],
    views: 2341
  },
  {
    id: 3,
    title: 'Setting Up Your Kali Linux Lab',
    excerpt: 'Step-by-step guide to setting up a professional penetration testing environment with Kali Linux.',
    image: '/images/tools-bg.jpg',
    date: '2024-03-05',
    readTime: '8 min',
    tags: ['Setup', 'Kali Linux'],
    views: 3102
  },
  {
    id: 4,
    title: 'Mastering Nmap: Advanced Scanning Techniques',
    excerpt: 'Deep dive into Nmap\'s advanced features for network reconnaissance and vulnerability scanning.',
    image: '/images/about-bg.jpg',
    date: '2024-02-28',
    readTime: '12 min',
    tags: ['Tools', 'Nmap'],
    views: 1856
  },
  {
    id: 5,
    title: 'Understanding Reverse Shells',
    excerpt: 'Learn how reverse shells work, how to create them, and how to detect them in your network.',
    image: '/images/contact-bg.jpg',
    date: '2024-02-20',
    readTime: '14 min',
    tags: ['Exploitation', 'Shells'],
    views: 2789
  },
  {
    id: 6,
    title: 'WiFi Hacking: From Basics to WPA3',
    excerpt: 'Complete guide to wireless network security testing using Aircrack-ng and other tools.',
    image: '/images/projects-bg.jpg',
    date: '2024-02-15',
    readTime: '20 min',
    tags: ['Wireless', 'WiFi'],
    views: 4521
  }
]

export default function BlogPage() {
  const router = useRouter()
  const { isAuthenticated } = useAuthStore()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/')
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen relative">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <Image
          src="/images/blog-bg.jpg"
          alt="Blog Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/80" />
        <div className="absolute inset-0 scanlines opacity-20" />
      </div>

      <Navbar />

      {/* Content */}
      <main className="relative z-10 pt-20 pb-16">
        {/* Header */}
        <section className="px-4 py-12">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                <span className="text-orange-400 glitch-text">Hacking</span>{' '}
                <span className="text-white">Blog</span>
              </h1>
              <p className="text-gray-400 max-w-2xl mx-auto">
                Tutorials, guides, and insights on cybersecurity and ethical hacking
              </p>
            </motion.div>

            {/* Featured Post */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mb-12"
            >
              <div className="glass rounded-2xl overflow-hidden border border-orange-500/30 group hover:border-orange-500/50 transition-colors">
                <div className="grid md:grid-cols-2 gap-0">
                  <div className="relative h-64 md:h-auto">
                    <Image
                      src={blogPosts[0].image}
                      alt={blogPosts[0].title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black/50 md:to-transparent" />
                  </div>
                  <div className="p-8 flex flex-col justify-center">
                    <div className="flex items-center gap-4 mb-4">
                      <span className="px-3 py-1 rounded-full bg-orange-500/20 text-orange-400 text-xs">
                        Featured
                      </span>
                      <span className="text-gray-500 text-sm flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {blogPosts[0].views.toLocaleString()}
                      </span>
                    </div>
                    <h2 className="text-2xl md:text-3xl font-bold text-white mb-4 group-hover:text-orange-400 transition-colors">
                      {blogPosts[0].title}
                    </h2>
                    <p className="text-gray-400 mb-6">{blogPosts[0].excerpt}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {blogPosts[0].date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {blogPosts[0].readTime}
                      </span>
                    </div>
                    <button className="self-start flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-lg hover:from-orange-400 hover:to-red-500 transition-all group">
                      Read Article
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Blog Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {blogPosts.slice(1).map((post, index) => (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * (index + 1) }}
                  className="glass rounded-xl overflow-hidden border border-gray-800 hover:border-cyan-500/50 transition-all group cursor-pointer"
                >
                  <div className="relative h-48">
                    <Image
                      src={post.image}
                      alt={post.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                    <div className="absolute bottom-4 left-4 flex gap-2">
                      {post.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-1 rounded bg-black/50 text-cyan-400 text-xs flex items-center gap-1"
                        >
                          <Tag className="w-3 h-3" />
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-lg font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-gray-500 text-sm mb-4 line-clamp-2">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between text-xs text-gray-600">
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {post.date}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {post.readTime}
                        </span>
                      </div>
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {post.views.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>

            {/* Load More */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="text-center mt-12"
            >
              <button className="px-8 py-3 border border-cyan-500/50 text-cyan-400 rounded-lg hover:bg-cyan-500/10 transition-all">
                Load More Articles
              </button>
            </motion.div>
          </div>
        </section>
      </main>
    </div>
  )
}
