'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { useAuthStore } from '@/lib/auth-store'
import { Navbar } from '@/components/navbar'
import { 
  Shield, 
  Award, 
  Code, 
  GraduationCap,
  Briefcase,
  Target,
  Heart
} from 'lucide-react'

const skills = [
  { name: 'Penetration Testing', level: 95 },
  { name: 'Network Security', level: 90 },
  { name: 'Web Application Security', level: 88 },
  { name: 'Reverse Engineering', level: 75 },
  { name: 'Malware Analysis', level: 70 },
  { name: 'Python & Bash', level: 92 },
]

const timeline = [
  {
    year: '2024',
    title: 'Senior Security Researcher',
    company: 'CyberDefense Corp',
    description: 'Leading red team operations and security assessments'
  },
  {
    year: '2022',
    title: 'Penetration Tester',
    company: 'SecureNet Labs',
    description: 'Conducted vulnerability assessments for Fortune 500 companies'
  },
  {
    year: '2020',
    title: 'Security Analyst',
    company: 'TechGuard Inc',
    description: 'Monitored and responded to security incidents'
  },
  {
    year: '2018',
    title: 'Started Journey',
    company: 'Self-Learning',
    description: 'Began exploring cybersecurity and ethical hacking'
  },
]

const certifications = [
  'OSCP - Offensive Security Certified Professional',
  'CEH - Certified Ethical Hacker',
  'CISSP - Certified Information Systems Security Professional',
  'CompTIA Security+',
  'eWPT - Web Application Penetration Testing',
]

export default function AboutPage() {
  const router = useRouter()
  const { isAuthenticated, currentUser } = useAuthStore()

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/')
    }
  }, [isAuthenticated, router])

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen relative">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <Image
          src="/images/about-bg.jpg"
          alt="About Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/75" />
        <div className="absolute inset-0 scanlines opacity-20" />
      </div>

      <Navbar />

      {/* Content */}
      <main className="relative z-10 pt-20 pb-16">
        {/* Hero */}
        <section className="px-4 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8"
            >
              <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-cyan-500 via-purple-500 to-red-500 p-1 mb-6">
                <div className="w-full h-full rounded-full bg-black overflow-hidden">
                  <Image
                    src="/images/hero-bg.jpg"
                    alt="Profile"
                    width={128}
                    height={128}
                    className="object-cover"
                  />
                </div>
              </div>
              
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                <span className="text-purple-400 glitch-text">About</span>{' '}
                <span className="text-white">Me</span>
              </h1>
              
              <p className="text-gray-400 text-lg max-w-2xl mx-auto leading-relaxed">
                {"I'm"} a passionate cybersecurity professional with a deep interest in ethical hacking, 
                penetration testing, and security research. My mission is to make the digital world 
                safer by identifying vulnerabilities before malicious actors do.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Story Section */}
        <section className="px-4 py-12">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="glass rounded-xl p-8 border border-purple-500/30"
            >
              <div className="flex items-center gap-3 mb-6">
                <Heart className="w-6 h-6 text-red-400" />
                <h2 className="text-2xl font-bold text-white">My Hacker Story</h2>
              </div>
              
              <div className="space-y-4 text-gray-400 leading-relaxed">
                <p>
                  My journey into cybersecurity began when I was 15, fascinated by how systems 
                  communicate and how they can be manipulated. What started as curiosity quickly 
                  turned into a passion for understanding the art of hacking.
                </p>
                <p>
                  Over the years, {"I've"} participated in numerous CTF competitions, reported 
                  critical vulnerabilities through bug bounty programs, and helped organizations 
                  strengthen their security posture. Every system has a story to tell, and {"I'm"} 
                  here to listen.
                </p>
                <p>
                  Today, I focus on web application security, network penetration testing, and 
                  security research. I believe in ethical hacking as a force for good, helping 
                  protect individuals and organizations from cyber threats.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Skills Section */}
        <section className="px-4 py-12">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center gap-3 mb-8">
                <Code className="w-6 h-6 text-cyan-400" />
                <h2 className="text-2xl font-bold text-white">Technical Skills</h2>
              </div>
              
              <div className="grid gap-4">
                {skills.map((skill, index) => (
                  <motion.div
                    key={skill.name}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="glass rounded-lg p-4 border border-gray-800"
                  >
                    <div className="flex justify-between mb-2">
                      <span className="text-white">{skill.name}</span>
                      <span className="text-cyan-400">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                        className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full"
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Timeline Section */}
        <section className="px-4 py-12">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-3 mb-8">
              <Briefcase className="w-6 h-6 text-orange-400" />
              <h2 className="text-2xl font-bold text-white">Experience</h2>
            </div>
            
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-cyan-500 via-purple-500 to-red-500" />
              
              {timeline.map((item, index) => (
                <motion.div
                  key={item.year}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative flex ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} gap-8 mb-8`}
                >
                  <div className="flex-1 hidden md:block" />
                  
                  {/* Dot */}
                  <div className="absolute left-4 md:left-1/2 w-3 h-3 -ml-1.5 rounded-full bg-cyan-500 border-2 border-black z-10" />
                  
                  <div className="flex-1 ml-10 md:ml-0">
                    <div className="glass rounded-xl p-6 border border-gray-800 hover:border-cyan-500/50 transition-colors">
                      <span className="text-cyan-400 font-bold">{item.year}</span>
                      <h3 className="text-xl font-bold text-white mt-1">{item.title}</h3>
                      <p className="text-purple-400 text-sm">{item.company}</p>
                      <p className="text-gray-500 mt-2">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Certifications */}
        <section className="px-4 py-12">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-3 mb-8">
              <Award className="w-6 h-6 text-yellow-400" />
              <h2 className="text-2xl font-bold text-white">Certifications</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              {certifications.map((cert, index) => (
                <motion.div
                  key={cert}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  className="glass rounded-lg p-4 border border-yellow-500/30 flex items-center gap-3"
                >
                  <GraduationCap className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                  <span className="text-gray-300 text-sm">{cert}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
