import type { Metadata } from 'next'
import { Fira_Code } from 'next/font/google'
import './globals.css'

const firaCode = Fira_Code({ 
  subsets: ['latin'],
  variable: '--font-fira-code'
})

export const metadata: Metadata = {
  title: 'Ethical Hacking & Cybersecurity',
  description: 'Professional cybersecurity expert and ethical hacker. Penetration testing, security audits, and Kali Linux expertise.',
  keywords: ['hacker', 'cybersecurity', 'pentesting', 'kali linux', 'ethical hacking'],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${firaCode.variable} bg-[#0a0a0f]`}>
      <body className="font-mono antialiased min-h-screen bg-[#0a0a0f] text-gray-200">
        {children}
      </body>
    </html>
  )
}
