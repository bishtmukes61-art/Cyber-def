'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { useAuthStore } from '@/lib/auth-store'
import { Navbar } from '@/components/navbar'
import { 
  Mail, 
  Send, 
  Instagram, 
  Twitter, 
  Youtube,
  Github,
  Linkedin,
  MessageSquare,
  CheckCircle,
  User,
  FileText
} from 'lucide-react'

// EDIT THESE LINKS - Replace with your actual social media links
const socialLinks = [
  {
    name: 'Email',
    icon: Mail,
    link: 'mailto cyberdefencewala@gmail.com?subject=Hello!',
    color: 'from-red-500 to-orange-600',
    username: 'cyberdefencewala@gmail.com'
  },
  {
    name: 'Instagram',
    icon: Instagram,
    link: 'https://instagram.com/theh4ck3r._.0',
    color: 'from-pink-500 to-purple-600',
    username: '@theh4ck3r._.0'
  },
  {
    name: 'Twitter',
    icon: Twitter,
    link: 'https://twitter.com/mukesbisht4345',
    color: 'from-cyan-500 to-blue-600',
    username: '@mukesbisht4345'
  },
  {
    name: 'YouTube',
    icon: Youtube,
    link: 'https://youtube.com/@YOUR_CHANNEL',
    color: 'from-red-600 to-red-700',
    username: '@YOUR_CHANNEL'
  },
  {
    name: 'GitHub',
    icon: Github,
    link: 'https://github.com/YOUR_USERNAME',
    color: 'from-gray-600 to-gray-800',
    username: '@YOUR_USERNAME'
  },
  {
    name: 'LinkedIn',
    icon: Linkedin,
    link: 'https://linkedin.com/in/YOUR_USERNAME',
    color: 'from-blue-600 to-blue-800',
    username: 'YOUR NAME'
  }
]

export default function ContactPage() {
  const router = useRouter()
  const { isAuthenticated } = useAuthStore()
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/')
    }
  }, [isAuthenticated, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsSubmitting(false)
    setIsSubmitted(true)
    setFormData({ name: '', email: '', subject: '', message: '' })
    
    setTimeout(() => setIsSubmitted(false), 5000)
  }

  if (!isAuthenticated) return null

  return (
    <div className="min-h-screen relative">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <Image
          src="/images/contact-bg.jpg"
          alt="Contact Background"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/75" />
        <div className="absolute inset-0 scanlines opacity-20" />
      </div>

      <Navbar />

      {/* Content */}
      <main className="relative z-10 pt-20 pb-16">
        {/* Header */}
        <section className="px-4 py-12">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                <span className="text-pink-400 glitch-text">Contact</span>{' '}
                <span className="text-white">Me</span>
              </h1>
              <p className="text-gray-400 max-w-2xl mx-auto">
                {"Let's"} connect! Reach out for collaborations, questions, or just to say hello.
              </p>
            </motion.div>

            <div className="grid lg:grid-cols-2 gap-8">
              {/* Social Links */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
              >
                <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                  <MessageSquare className="w-6 h-6 text-pink-400" />
                  Connect With Me
                </h2>

                <div className="grid grid-cols-2 gap-4">
                  {socialLinks.map((social, index) => (
                    <motion.a
                      key={social.name}
                      href={social.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 * index }}
                      whileHover={{ scale: 1.05, y: -2 }}
                      className="glass rounded-xl p-4 border border-gray-800 hover:border-pink-500/50 transition-all group"
                    >
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${social.color} flex items-center justify-center mb-3 group-hover:shadow-lg transition-shadow`}>
                        <social.icon className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="text-white font-semibold group-hover:text-pink-400 transition-colors">
                        {social.name}
                      </h3>
                      <p className="text-gray-500 text-sm truncate">
                        {social.username}
                      </p>
                    </motion.a>
                  ))}
                </div>

                {/* Quick Actions */}
                <div className="mt-8 space-y-4">
                  <motion.a
                    href="mailto cyberdefencewala@gmail.com?subject=Collaboration Request"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="flex items-center gap-4 glass rounded-xl p-4 border border-cyan-500/30 hover:border-cyan-500/50 transition-all group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold group-hover:text-cyan-400 transition-colors">
                        Quick Email
                      </h3>
                      <p className="text-gray-500 text-sm">
                        Click to open email client with pre-filled subject
                      </p>
                    </div>
                  </motion.a>
                </div>
              </motion.div>

              {/* Contact Form */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                  <Send className="w-6 h-6 text-cyan-400" />
                  Send a Message
                </h2>

                <form onSubmit={handleSubmit} className="glass rounded-xl p-6 border border-gray-800">
                  {isSubmitted && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-2 p-4 mb-6 rounded-lg bg-green-500/10 border border-green-500/30 text-green-400"
                    >
                      <CheckCircle className="w-5 h-5" />
                      <span>Message sent successfully! {"I'll"} get back to you soon.</span>
                    </motion.div>
                  )}

                  <div className="space-y-4">
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                      <input
                        type="text"
                        placeholder="Your Name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                        className="w-full pl-11 pr-4 py-3 bg-black/30 border border-gray-700 rounded-lg focus:border-cyan-500 focus:outline-none text-white placeholder-gray-500"
                      />
                    </div>

                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                      <input
                        type="email"
                        placeholder="Your Email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        className="w-full pl-11 pr-4 py-3 bg-black/30 border border-gray-700 rounded-lg focus:border-cyan-500 focus:outline-none text-white placeholder-gray-500"
                      />
                    </div>

                    <div className="relative">
                      <FileText className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                      <input
                        type="text"
                        placeholder="Subject"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        required
                        className="w-full pl-11 pr-4 py-3 bg-black/30 border border-gray-700 rounded-lg focus:border-cyan-500 focus:outline-none text-white placeholder-gray-500"
                      />
                    </div>

                    <div className="relative">
                      <MessageSquare className="absolute left-3 top-4 w-5 h-5 text-gray-500" />
                      <textarea
                        placeholder="Your Message"
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        required
                        rows={5}
                        className="w-full pl-11 pr-4 py-3 bg-black/30 border border-gray-700 rounded-lg focus:border-cyan-500 focus:outline-none text-white placeholder-gray-500 resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold rounded-lg hover:from-pink-400 hover:to-purple-500 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {isSubmitting ? (
                        <>
                          <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5" />
                          Send Message
                        </>
                      )}
                    </button>
                  </div>
                </form>

                {/* Note */}
                <p className="mt-4 text-center text-gray-600 text-sm">
                  This form sending.
                </p>
              </motion.div>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
